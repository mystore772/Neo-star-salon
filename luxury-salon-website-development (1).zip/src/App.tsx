import { useState, useEffect, useRef, type ReactNode } from "react";
import {
  MessageCircle, Phone, MapPin, Clock, Star, ChevronDown, ChevronUp,
  Menu, X, Sparkles, Scissors, Hand, Sun, Moon, Heart, Flower2,
  Palette, Crown, Award, Users, Shield, ArrowRight, Mail, Navigation,
  Bookmark, ExternalLink, Quote, Gem, Zap, Diamond,
  Play,
} from "lucide-react";

/* ───────────────────────── CONSTANTS ───────────────────────── */
const WHATSAPP_NUMBER = "919999999999";
const PHONE_NUMBER = "+919999999999";
const ADDRESS = "Shri Ramplaza, Gher Khatti, New Mandi, Muzaffarnagar, Uttar Pradesh 251001";
const MAPS_URL = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(ADDRESS)}`;
const WHATSAPP_LINK = `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent("Hi! I'd like to book an appointment at Neo Star Salon.")}`;
const CALL_LINK = `tel:${PHONE_NUMBER}`;
const DIRECTIONS_LINK = MAPS_URL;

const SERVICES = [
  { icon: <Sparkles className="w-7 h-7" />, title: "Ultrasonic Facial", desc: "Deep cleansing ultrasonic treatment for radiant, rejuvenated skin with premium products and LED therapy." },
  { icon: <Sun className="w-7 h-7" />, title: "Tanning", desc: "Safe, sun-kissed glow with premium tanning solutions for a natural bronze finish that lasts." },
  { icon: <Flower2 className="w-7 h-7" />, title: "Pedicure", desc: "Luxury foot care with exfoliation, hot stone massage, and flawless nail finishing." },
  { icon: <Hand className="w-7 h-7" />, title: "Body Waxing", desc: "Smooth, gentle waxing with premium hard waxes for silky, hair-free skin." },
  { icon: <Palette className="w-7 h-7" />, title: "Make-up Services", desc: "Professional HD & airbrush makeup for weddings, parties, and special occasions." },
  { icon: <Gem className="w-7 h-7" />, title: "Manicure", desc: "Elegant nail care with shaping, cuticle treatment, gel polish, and hand massage." },
  { icon: <Zap className="w-7 h-7" />, title: "Skin Treatments", desc: "Advanced facials, chemical peels, and skincare therapies tailored to your skin type." },
  { icon: <Scissors className="w-7 h-7" />, title: "Hairstyling", desc: "Trend-setting cuts, balayage, keratin treatments, and styling by expert hair artists." },
  { icon: <Crown className="w-7 h-7" />, title: "Barber Services", desc: "Classic and modern men's grooming with precision cuts, beard sculpting, and hot towel shaves." },
];

const REVIEWS = [
  { name: "Priya Sharma", rating: 5, text: "Absolutely amazing experience! The facial treatment left my skin glowing for days. The staff is incredibly professional and the ambiance is luxurious.", time: "2 weeks ago", avatar: "PS" },
  { name: "Rahul Verma", rating: 5, text: "Best salon in Muzaffarnagar! The barber services are top-notch. Clean, professional, and the attention to detail is remarkable.", time: "1 month ago", avatar: "RV" },
  { name: "Anjali Gupta", rating: 5, text: "Got my bridal makeup done here and it was perfect! They understood exactly what I wanted. Premium quality products.", time: "3 weeks ago", avatar: "AG" },
  { name: "Vikram Singh", rating: 5, text: "The hair styling here is fantastic. Modern cuts with a classic touch. The stylists really know their craft. Will definitely come back!", time: "1 week ago", avatar: "VS" },
  { name: "Neha Agarwal", rating: 5, text: "Wonderful pedicure experience! Very hygienic and relaxing. The staff is courteous and the salon has a great premium feel.", time: "2 months ago", avatar: "NA" },
  { name: "Amit Kumar", rating: 5, text: "Top rated salon for a reason! Every visit feels special. The grooming services are exceptional and prices are fair.", time: "3 months ago", avatar: "AK" },
];

const GALLERY_IMAGES = [
  { src: "/images/gallery-1.jpg", alt: "Luxury salon styling station" },
  { src: "/images/gallery-2.jpg", alt: "Premium facial treatment room" },
  { src: "/images/gallery-3.jpg", alt: "Elegant manicure station" },
  { src: "/images/gallery-4.jpg", alt: "Professional barber station" },
  { src: "/images/about-salon.jpg", alt: "Salon interior ambiance" },
  { src: "/images/storefront.jpg", alt: "Neo Star Salon storefront" },
];

/* ───────────────────────── HOOKS ───────────────────────── */
function useScrollReveal() {
  const ref = useRef<HTMLDivElement>(null);
  const [visible, setVisible] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const obs = new IntersectionObserver(
      ([e]) => { if (e.isIntersecting) { setVisible(true); obs.unobserve(el); } },
      { threshold: 0.1 }
    );
    obs.observe(el);
    return () => obs.disconnect();
  }, []);
  return { ref, visible };
}

function useScrolledNav() {
  const [scrolled, setScrolled] = useState(false);
  useEffect(() => {
    const h = () => setScrolled(window.scrollY > 60);
    window.addEventListener("scroll", h, { passive: true });
    return () => window.removeEventListener("scroll", h);
  }, []);
  return scrolled;
}

/* ───────────────────────── GOLD DUST PARTICLES ───────────────────────── */
function GoldDustParticles() {
  const particles = Array.from({ length: 30 }, (_, i) => ({
    id: i,
    left: `${Math.random() * 100}%`,
    bottom: `${Math.random() * 30}%`,
    size: Math.random() * 4 + 2,
    delay: Math.random() * 6,
    duration: Math.random() * 4 + 4,
    opacity: Math.random() * 0.5 + 0.2,
  }));

  return (
    <div className="gold-dust-container">
      {particles.map((p) => (
        <div
          key={p.id}
          className="gold-dust"
          style={{
            left: p.left,
            bottom: p.bottom,
            width: p.size,
            height: p.size,
            animationDelay: `${p.delay}s`,
            animationDuration: `${p.duration}s`,
            opacity: p.opacity,
          }}
        />
      ))}
    </div>
  );
}

/* ───────────────────────── SMALL COMPONENTS ───────────────────────── */

function SectionHeader({ dark, subtitle, title, light }: { dark: boolean; subtitle: string; title: string; light?: ReactNode }) {
  return (
    <div className="text-center mb-14 md:mb-20">
      <div className="flex items-center justify-center gap-3 mb-4">
        <div className="w-8 h-px bg-gradient-to-r from-transparent to-gold/60" />
        <p className="text-gold font-semibold tracking-[0.3em] uppercase text-[10px] md:text-xs">{subtitle}</p>
        <div className="w-8 h-px bg-gradient-to-l from-transparent to-gold/60" />
      </div>
      <h2 className={`font-display text-3xl md:text-5xl lg:text-6xl font-bold leading-tight ${dark ? "gradient-text-dark" : "text-charcoal"}`}>
        {title}
      </h2>
      {light && (
        <>
          <div className="mt-5 flex justify-center">
            <div className="w-16 h-px bg-gradient-to-r from-transparent via-gold to-transparent" />
            <div className="mx-2 w-2 h-2 rounded-full bg-gold/40" />
            <div className="w-16 h-px bg-gradient-to-r from-transparent via-gold to-transparent" />
          </div>
          <p className={`mt-4 max-w-2xl mx-auto text-sm md:text-base leading-relaxed ${dark ? "text-gray-500" : "text-gray-500"}`}>{light}</p>
        </>
      )}
    </div>
  );
}

function GoldDivider() {
  return (
    <div className="flex items-center justify-center py-1">
      <div className="section-divider w-full max-w-5xl mx-auto" />
    </div>
  );
}

function OpenBadge({ dark }: { dark: boolean }) {
  const now = new Date();
  const h = now.getHours();
  const isOpen = h >= 9 && h < 21;
  return (
    <span className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[10px] font-bold tracking-wider uppercase ${isOpen ? "bg-emerald-500/10 text-emerald-400" : "bg-red-500/10 text-red-400"} ${dark ? "border border-white/5" : "border border-black/5"}`}>
      <span className={`w-1.5 h-1.5 rounded-full ${isOpen ? "bg-emerald-400 animate-pulse" : "bg-red-400"}`} />
      {isOpen ? "Open Now" : "Closed"}
    </span>
  );
}

/* ───────────────────────── NAVBAR ───────────────────────── */
function Navbar({ dark, setDark }: { dark: boolean; setDark: (v: boolean) => void }) {
  const scrolled = useScrolledNav();
  const [menuOpen, setMenuOpen] = useState(false);
  const navLinks = [
    { label: "Home", href: "#hero" },
    { label: "About", href: "#about" },
    { label: "Services", href: "#services" },
    { label: "Gallery", href: "#gallery" },
    { label: "Reviews", href: "#reviews" },
    { label: "Contact", href: "#contact" },
  ];

  return (
    <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-700 ${scrolled ? "py-1.5" : "py-3 md:py-4"}`}>
      <div className={`mx-2 md:mx-5 lg:mx-auto lg:max-w-7xl rounded-2xl transition-all duration-700 ${scrolled
        ? (dark
          ? "bg-[#0A0A0A]/80 glass shadow-2xl shadow-black/40 border border-white/5"
          : "bg-white/85 glass shadow-2xl shadow-black/8 border border-gold/10")
        : "bg-transparent"
      }`}>
        <div className="flex items-center justify-between px-4 md:px-7 py-2.5">
          {/* Logo */}
          <a href="#hero" className="flex items-center gap-2.5 group">
            <div className="relative">
              <Diamond className="w-5 h-5 text-gold group-hover:rotate-90 transition-transform duration-700" />
              <div className="absolute inset-0 bg-gold/20 rounded-full blur-md opacity-0 group-hover:opacity-100 transition-opacity" />
            </div>
            <span className="font-display text-lg md:text-xl font-bold tracking-tight">
              <span className="text-gold">Neo</span>
              <span className={`transition-colors ${dark ? "text-white" : "text-charcoal"}`}> Star</span>
            </span>
          </a>

          {/* Desktop Links */}
          <div className="hidden lg:flex items-center gap-1">
            {navLinks.map((l) => (
              <a key={l.href} href={l.href} className={`relative px-4 py-2 text-[13px] font-medium tracking-wide transition-colors hover:text-gold ${dark ? "text-gray-400" : "text-gray-600"} group`}>
                {l.label}
                <span className="absolute bottom-0 left-1/2 -translate-x-1/2 w-0 h-[2px] bg-gold group-hover:w-4/5 transition-all duration-300 rounded-full" />
              </a>
            ))}
          </div>

          {/* Right side */}
          <div className="flex items-center gap-2 md:gap-3">
            <div className="hidden md:block">
              <OpenBadge dark={dark} />
            </div>
            {/* Theme toggle */}
            <button
              onClick={() => setDark(!dark)}
              className={`relative w-[52px] h-7 rounded-full transition-all duration-500 ${dark
                ? "bg-dark-elevated border border-gold/20"
                : "bg-gold/15 border border-gold/30"
              }`}
              aria-label="Toggle theme"
            >
              <span className={`absolute top-[3px] w-[22px] h-[22px] rounded-full flex items-center justify-center transition-all duration-500 shadow-lg ${dark
                ? "left-[calc(100%-25px)] bg-gradient-to-br from-gold to-gold-dark shadow-gold/30"
                : "left-[3px] bg-gradient-to-br from-gold-light to-gold shadow-gold/30"
              }`}>
                {dark ? <Moon className="w-3 h-3 text-dark-bg" /> : <Sun className="w-3 h-3 text-dark-bg" />}
              </span>
            </button>
            {/* Book CTA */}
            <a href={WHATSAPP_LINK} target="_blank" rel="noopener noreferrer" className="hidden md:inline-flex items-center gap-2 btn-gold text-dark-bg font-bold text-[13px] px-5 py-2.5 rounded-xl">
              <MessageCircle className="w-4 h-4" /> Book Now
            </a>
            {/* Mobile menu */}
            <button onClick={() => setMenuOpen(!menuOpen)} className={`lg:hidden p-2 rounded-xl transition-all ${dark ? "text-white hover:bg-white/5" : "text-charcoal hover:bg-black/5"}`} aria-label="Menu">
              {menuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>

        {/* Premium Mobile menu */}
        <div className={`lg:hidden overflow-hidden transition-all duration-500 ease-[cubic-bezier(0.16,1,0.3,1)] ${menuOpen ? "max-h-[500px] opacity-100" : "max-h-0 opacity-0"}`}>
          <div className={`mx-3 mb-3 rounded-2xl p-2 ${dark ? "bg-dark-card/90 glass border border-white/5" : "bg-white/95 glass border border-gold/10"}`}>
            {navLinks.map((l, i) => (
              <a
                key={l.href}
                href={l.href}
                onClick={() => setMenuOpen(false)}
                className={`mobile-nav-item flex items-center gap-3 ${dark ? "text-gray-300 hover:text-gold hover:bg-gold/5" : "text-gray-700 hover:text-gold hover:bg-gold/5"}`}
                style={{ animationDelay: `${i * 50}ms` }}
              >
                <div className="w-1 h-1 rounded-full bg-gold/30" />
                <span className="text-sm font-medium">{l.label}</span>
              </a>
            ))}
            <div className="mt-2 px-2">
              <a href={WHATSAPP_LINK} target="_blank" rel="noopener noreferrer" className="flex items-center justify-center gap-2 bg-gradient-to-r from-gold to-gold-light text-dark-bg font-bold text-sm px-5 py-3.5 rounded-xl">
                <MessageCircle className="w-4 h-4" /> Book on WhatsApp
              </a>
            </div>
          </div>
        </div>
      </div>
    </nav>
  );
}

/* ───────────────────────── HERO ───────────────────────── */
function Hero() {
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    const t = setTimeout(() => setLoaded(true), 100);
    return () => clearTimeout(t);
  }, []);

  return (
    <section id="hero" className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background layers */}
      <div className="absolute inset-0">
        <img
          src="/images/hero-bg.jpg"
          alt="Neo Star Salon Interior"
          className={`w-full h-full object-cover transition-all duration-[2s] ${loaded ? "scale-100" : "scale-110"}`}
        />
        {/* Cinematic dark overlay */}
        <div className="hero-overlay absolute inset-0" />
        {/* Gold vignette */}
        <div className="hero-gold-vignette absolute inset-0" />
        {/* Bottom fade to dark */}
        <div className="absolute inset-0 bg-gradient-to-t from-[#0A0A0A] via-transparent to-[rgba(10,10,10,0.3)]" />
        {/* Subtle gold ambient glow */}
        <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-[800px] h-[400px] bg-gold/[0.04] rounded-full blur-[100px]" />
      </div>

      {/* Gold dust particles */}
      <GoldDustParticles />

      {/* Decorative spinning ring */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] md:w-[700px] md:h-[700px] border border-gold/[0.04] rounded-full animate-spin-slow pointer-events-none" />
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[350px] h-[350px] md:w-[500px] md:h-[500px] border border-gold/[0.06] rounded-full animate-spin-slow pointer-events-none" style={{ animationDirection: "reverse", animationDuration: "30s" }} />

      {/* Content */}
      <div className="relative z-10 text-center px-5 max-w-5xl mx-auto">
        {/* Premium Badge */}
        <div className={`inline-flex items-center gap-2.5 bg-gold/[0.08] border border-gold/20 rounded-full px-5 py-2 mb-10 ${loaded ? "animate-badge-reveal" : "opacity-0"}`}>
          <Award className="w-4 h-4 text-gold" />
          <span className="text-gold text-[10px] font-bold tracking-[0.2em] uppercase">Top Rated Salon</span>
          <span className="text-gold text-sm">⭐</span>
        </div>

        {/* Headline */}
        <h1 className={`font-display font-bold text-white leading-[1.05] mb-8 ${loaded ? "animate-hero-text" : "opacity-0"}`}
          style={{ fontSize: "clamp(2.5rem, 8vw, 6rem)" }}
        >
          <span className="block text-shadow-premium">Luxury Grooming.</span>
          <span className="block gold-shimmer animate-gold-pulse mt-2">Premium Style.</span>
        </h1>

        {/* Elegant line ornament */}
        <div className={`flex items-center justify-center gap-3 mb-8 ${loaded ? "animate-line-expand" : "opacity-0"}`} style={{ animationDelay: "0.4s" }}>
          <div className="w-12 md:w-20 h-px bg-gradient-to-r from-transparent to-gold/50" />
          <Diamond className="w-3 h-3 text-gold/60" />
          <div className="w-12 md:w-20 h-px bg-gradient-to-l from-transparent to-gold/50" />
        </div>

        {/* Subtitle */}
        <p className={`text-gray-400 text-sm md:text-lg max-w-2xl mx-auto mb-12 leading-relaxed ${loaded ? "animate-fade-in-up" : "opacity-0"}`}
          style={{ animationDelay: "0.5s" }}
        >
          Experience the finest grooming & beauty services at Muzaffarnagar&apos;s most
          <span className="text-gold/80"> premium salon</span>. Where luxury meets artistry.
        </p>

        {/* CTAs */}
        <div className={`flex flex-col sm:flex-row items-center justify-center gap-4 ${loaded ? "animate-fade-in-up" : "opacity-0"}`}
          style={{ animationDelay: "0.7s" }}
        >
          <a href={WHATSAPP_LINK} target="_blank" rel="noopener noreferrer" className="group relative flex items-center gap-3 bg-gradient-to-r from-gold via-gold-light to-gold text-dark-bg font-bold text-sm md:text-base px-8 py-4 rounded-2xl transition-all duration-300 hover:shadow-[0_8px_40px_rgba(212,175,55,0.35)] hover:scale-[1.02]">
            <span className="absolute inset-0 rounded-2xl bg-gradient-to-r from-gold-light via-gold to-gold-light opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
            <MessageCircle className="w-5 h-5 relative z-10" />
            <span className="relative z-10">Book on WhatsApp</span>
            <ArrowRight className="w-4 h-4 relative z-10 group-hover:translate-x-1 transition-transform" />
          </a>
          <a href="#services" className="group flex items-center gap-3 border border-gold/30 hover:border-gold/60 text-gold font-semibold text-sm md:text-base px-8 py-4 rounded-2xl transition-all duration-300 hover:bg-gold/[0.06] hover:shadow-[0_4px_20px_rgba(212,175,55,0.1)]">
            <Play className="w-4 h-4" />
            View Services
          </a>
        </div>

        {/* Trust indicators */}
        <div className={`flex items-center justify-center gap-6 md:gap-10 mt-14 ${loaded ? "animate-fade-in-up" : "opacity-0"}`}
          style={{ animationDelay: "0.9s" }}
        >
          {[
            { value: "4.9", label: "Rating", icon: <Star className="w-3.5 h-3.5 text-gold fill-gold" /> },
            { value: "200+", label: "Reviews", icon: <Award className="w-3.5 h-3.5 text-gold" /> },
            { value: "9+", label: "Services", icon: <Sparkles className="w-3.5 h-3.5 text-gold" /> },
          ].map((item, i) => (
            <div key={i} className="flex items-center gap-2">
              {item.icon}
              <div className="text-left">
                <p className="text-white font-bold text-sm md:text-base">{item.value}</p>
                <p className="text-gray-500 text-[10px] md:text-xs uppercase tracking-wider">{item.label}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Scroll arrow */}
      <a href="#about" className="absolute bottom-8 md:bottom-12 left-1/2 animate-bounce-arrow text-gold/40 hover:text-gold/80 transition-colors group">
        <div className="flex flex-col items-center gap-2">
          <span className="text-[9px] uppercase tracking-[0.3em] text-gold/40 group-hover:text-gold/60 transition-colors">Scroll</span>
          <ChevronDown className="w-5 h-5" />
        </div>
      </a>

      {/* Bottom gradient fade */}
      <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-[#0A0A0A] to-transparent pointer-events-none" />
    </section>
  );
}

/* ───────────────────────── ABOUT ───────────────────────── */
function About({ dark }: { dark: boolean }) {
  const rev = useScrollReveal();
  const rev2 = useScrollReveal();
  const perks = [
    { icon: <Award className="w-5 h-5" />, text: "Premium Products" },
    { icon: <Users className="w-5 h-5" />, text: "Expert Stylists" },
    { icon: <Shield className="w-5 h-5" />, text: "Hygiene First" },
    { icon: <Zap className="w-5 h-5" />, text: "Latest Techniques" },
  ];

  return (
    <section id="about" className={`py-20 md:py-32 relative overflow-hidden ${dark ? "dark-luxury" : "bg-light-bg"}`}>
      {/* Ambient glow */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-gold/[0.03] rounded-full blur-[120px]" />
      <div className="absolute bottom-0 left-0 w-80 h-80 bg-gold/[0.02] rounded-full blur-[100px]" />

      <div className="max-w-7xl mx-auto px-5 md:px-8">
        <div className="grid lg:grid-cols-2 gap-14 lg:gap-24 items-center">
          {/* Image */}
          <div ref={rev.ref} className={`reveal-left ${rev.visible ? "visible" : ""}`}>
            <div className="relative group">
              {/* Gold glow behind image */}
              <div className="absolute -inset-6 bg-gradient-to-br from-gold/10 via-gold/5 to-transparent rounded-[2rem] blur-2xl opacity-60 group-hover:opacity-90 transition-opacity duration-700" />
              <div className="relative">
                <img
                  src="/images/about-salon.jpg"
                  alt="Inside Neo Star Salon"
                  className={`relative rounded-3xl w-full aspect-[4/5] object-cover ${dark ? "shadow-2xl shadow-black/60" : "shadow-2xl shadow-black/10"}`}
                />
                {/* Gold border overlay */}
                <div className="absolute inset-0 rounded-3xl border border-gold/10 pointer-events-none" />
              </div>
              {/* Floating rating badge */}
              <div className={`absolute -bottom-5 -right-2 md:right-6 glass rounded-2xl p-4 md:p-5 shadow-2xl ${dark
                ? "bg-dark-card/70 border border-gold/15"
                : "bg-white/80 border border-gold/20"
              }`}>
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-gradient-to-br from-gold/20 to-gold/5 rounded-xl flex items-center justify-center">
                    <Star className="w-6 h-6 text-gold fill-gold" />
                  </div>
                  <div>
                    <p className={`font-bold text-lg ${dark ? "text-white" : "text-charcoal"}`}>4.9 / 5</p>
                    <p className="text-gold text-[10px] font-bold tracking-wider uppercase">200+ Reviews</p>
                  </div>
                </div>
              </div>
              {/* Decorative corner accent */}
              <div className="absolute -top-3 -left-3 w-16 h-16 border-t-2 border-l-2 border-gold/20 rounded-tl-3xl" />
              <div className="absolute -bottom-3 -right-3 w-16 h-16 border-b-2 border-r-2 border-gold/20 rounded-br-3xl" />
            </div>
          </div>

          {/* Text */}
          <div ref={rev2.ref} className={`reveal-right ${rev2.visible ? "visible" : ""}`}>
            <div className="flex items-center gap-3 mb-5">
              <div className="w-8 h-px bg-gradient-to-r from-gold to-transparent" />
              <p className="text-gold font-bold tracking-[0.25em] uppercase text-[10px]">About Us</p>
            </div>
            <h2 className={`font-display text-3xl md:text-5xl font-bold leading-tight mb-6 ${dark ? "gradient-text-dark" : "text-charcoal"}`}>
              Where Beauty Meets <span className="gold-text">Elegance</span>
            </h2>
            <div className="flex items-center gap-2 mb-8">
              <div className="w-10 h-px bg-gold/50" />
              <div className="w-1.5 h-1.5 rounded-full bg-gold/40" />
              <div className="w-10 h-px bg-gold/50" />
            </div>
            <p className={`text-base md:text-lg leading-relaxed mb-4 ${dark ? "text-gray-400" : "text-gray-600"}`}>
              Welcome to <strong className={`font-semibold ${dark ? "text-white" : "text-charcoal"}`}>Neo Star Salon</strong> — Muzaffarnagar&apos;s premier destination for luxury grooming and beauty services. Nestled in the heart of New Mandi, we combine artistry, premium products, and a passion for perfection.
            </p>
            <p className={`text-base md:text-lg leading-relaxed mb-10 ${dark ? "text-gray-500" : "text-gray-500"}`}>
              From precision haircuts to rejuvenating facials, our team of expert stylists is dedicated to making every visit an unforgettable experience. Step into our world of elegance.
            </p>

            {/* Perks */}
            <div className="grid grid-cols-2 gap-3 mb-10">
              {perks.map((p, i) => (
                <div key={i} className={`flex items-center gap-3 p-4 rounded-xl border transition-all duration-300 hover:border-gold/20 ${dark
                  ? "bg-dark-card/40 border-white/5 text-gold"
                  : "bg-white border-gold/10 text-gold"
                }`}>
                  {p.icon}
                  <span className={`text-xs font-semibold tracking-wide ${dark ? "text-gray-300" : "text-gray-700"}`}>{p.text}</span>
                </div>
              ))}
            </div>

            <a href={WHATSAPP_LINK} target="_blank" rel="noopener noreferrer" className="group inline-flex items-center gap-3 btn-gold text-dark-bg font-bold px-8 py-4 rounded-2xl text-sm">
              <MessageCircle className="w-5 h-5 relative z-10" />
              <span className="relative z-10">Book Appointment</span>
              <ArrowRight className="w-4 h-4 relative z-10 group-hover:translate-x-1 transition-transform" />
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}

/* ───────────────────────── SERVICES ───────────────────────── */
function Services({ dark }: { dark: boolean }) {
  const rev = useScrollReveal();
  const [expanded, setExpanded] = useState<number | null>(null);

  return (
    <section id="services" className={`py-20 md:py-32 relative ${dark ? "dark-gradient" : "light-gradient"}`}>
      {/* Ambient */}
      <div className="absolute top-1/3 left-0 w-72 h-72 bg-gold/[0.03] rounded-full blur-[100px]" />
      <div className="absolute bottom-1/4 right-0 w-96 h-96 bg-gold/[0.02] rounded-full blur-[120px]" />

      <div className="max-w-7xl mx-auto px-5 md:px-8">
        <div ref={rev.ref} className={`reveal ${rev.visible ? "visible" : ""}`}>
          <SectionHeader
            dark={dark}
            subtitle="Our Services"
            title="Premium Services"
            light="Discover our range of luxury grooming and beauty treatments, each designed to leave you looking and feeling your absolute best."
          />
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-5">
          {SERVICES.map((s, i) => {
            const r = useScrollReveal();
            return (
              <div
                key={i}
                ref={r.ref}
                className={`reveal service-card card-premium group rounded-2xl p-6 md:p-7 cursor-pointer border relative overflow-hidden ${dark
                  ? "bg-dark-card/40 border-white/[0.06] hover:border-gold/25 hover:bg-dark-card/70"
                  : "bg-white border-gold/[0.08] hover:border-gold/30 hover:shadow-xl hover:shadow-gold/[0.06]"
                } ${r.visible ? "visible" : ""}`}
                style={{ transitionDelay: `${i * 60}ms` }}
                onClick={() => setExpanded(expanded === i ? null : i)}
              >
                {/* Hover gold gradient */}
                <div className="absolute inset-0 bg-gradient-to-br from-gold/[0.06] to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none" />

                <div className="relative z-10">
                  <div className="flex items-start justify-between mb-5">
                    <div className={`w-14 h-14 rounded-2xl flex items-center justify-center transition-all duration-300 ${dark
                      ? "bg-gold/[0.08] text-gold group-hover:bg-gold/[0.15] group-hover:shadow-lg group-hover:shadow-gold/10"
                      : "bg-gold/[0.08] text-gold group-hover:bg-gold/[0.15] group-hover:shadow-lg group-hover:shadow-gold/10"
                    }`}>
                      {s.icon}
                    </div>
                    <span className="text-gold/50 text-lg mt-1">
                      {expanded === i ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                    </span>
                  </div>
                  <h3 className={`font-display text-lg md:text-xl font-bold mb-2 transition-colors ${dark ? "text-white group-hover:text-gold" : "text-charcoal group-hover:text-gold"}`}>{s.title}</h3>
                  <div className={`overflow-hidden transition-all duration-500 ease-[cubic-bezier(0.16,1,0.3,1)] ${expanded === i ? "max-h-40 opacity-100 mt-1" : "max-h-0 opacity-0"}`}>
                    <p className={`text-sm leading-relaxed ${dark ? "text-gray-400" : "text-gray-600"}`}>{s.desc}</p>
                  </div>
                  {expanded !== i && (
                    <p className={`text-[11px] mt-2 font-medium tracking-wide ${dark ? "text-gray-600" : "text-gray-400"}`}>Tap to explore →</p>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        {/* Booking CTA */}
        <div className="text-center mt-16">
          <a href={WHATSAPP_LINK} target="_blank" rel="noopener noreferrer" className="group inline-flex items-center gap-3 btn-gold text-dark-bg font-bold px-10 py-4 rounded-2xl text-sm">
            <MessageCircle className="w-5 h-5 relative z-10" />
            <span className="relative z-10">Book Your Service</span>
            <ArrowRight className="w-4 h-4 relative z-10 group-hover:translate-x-1 transition-transform" />
          </a>
        </div>
      </div>
    </section>
  );
}

/* ───────────────────────── GALLERY ───────────────────────── */
function Gallery({ dark }: { dark: boolean }) {
  const rev = useScrollReveal();
  const [lightbox, setLightbox] = useState<number | null>(null);

  const next = () => setLightbox((p) => (p !== null ? (p + 1) % GALLERY_IMAGES.length : null));
  const prev = () => setLightbox((p) => (p !== null ? (p - 1 + GALLERY_IMAGES.length) % GALLERY_IMAGES.length : null));

  return (
    <section id="gallery" className={`py-20 md:py-32 relative ${dark ? "dark-luxury" : "bg-light-bg"}`}>
      <div className="max-w-7xl mx-auto px-5 md:px-8">
        <div ref={rev.ref} className={`reveal ${rev.visible ? "visible" : ""}`}>
          <SectionHeader dark={dark} subtitle="Our Gallery" title="Inside the Salon" light="Take a peek at our elegant interiors, premium stations, and the luxurious experience that awaits you." />
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 gap-2.5 md:gap-4">
          {GALLERY_IMAGES.map((img, i) => {
            const r = useScrollReveal();
            return (
              <div
                key={i}
                ref={r.ref}
                className={`reveal-scale cursor-pointer group relative overflow-hidden rounded-2xl ${r.visible ? "visible" : ""} ${i === 0 ? "row-span-2 aspect-auto" : "aspect-square"}`}
                style={{ transitionDelay: `${i * 80}ms` }}
                onClick={() => setLightbox(i)}
              >
                <img src={img.src} alt={img.alt} className="gallery-img w-full h-full object-cover" loading="lazy" />
                {/* Hover overlay */}
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/0 to-black/0 opacity-0 group-hover:opacity-100 transition-all duration-500">
                  <div className="absolute bottom-4 left-4 right-4">
                    <p className="text-white text-sm font-medium">{img.alt}</p>
                  </div>
                </div>
                <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  <div className="w-12 h-12 rounded-full bg-white/10 glass flex items-center justify-center">
                    <ExternalLink className="w-5 h-5 text-white" />
                  </div>
                </div>
                {/* Gold border on hover */}
                <div className="absolute inset-0 border-2 border-gold/0 group-hover:border-gold/30 rounded-2xl transition-all duration-500 pointer-events-none" />
              </div>
            );
          })}
        </div>

        {/* Lightbox */}
        {lightbox !== null && (
          <div className="fixed inset-0 z-[60] bg-black/95 lightbox-overlay flex items-center justify-center p-4" onClick={() => setLightbox(null)}>
            <button onClick={() => setLightbox(null)} className="absolute top-5 right-5 text-white/50 hover:text-white z-10 transition-colors">
              <X className="w-8 h-8" />
            </button>
            <button onClick={(e) => { e.stopPropagation(); prev(); }} className="absolute left-3 md:left-8 text-white/50 hover:text-white z-10 w-10 h-10 bg-white/5 glass rounded-full flex items-center justify-center transition-colors">
              <ChevronDown className="w-5 h-5 rotate-90" />
            </button>
            <button onClick={(e) => { e.stopPropagation(); next(); }} className="absolute right-3 md:right-8 text-white/50 hover:text-white z-10 w-10 h-10 bg-white/5 glass rounded-full flex items-center justify-center transition-colors">
              <ChevronDown className="w-5 h-5 -rotate-90" />
            </button>
            <img
              src={GALLERY_IMAGES[lightbox].src}
              alt={GALLERY_IMAGES[lightbox].alt}
              className="max-h-[85vh] max-w-[90vw] rounded-2xl object-contain animate-scale-in shadow-2xl shadow-black/50"
              onClick={(e) => e.stopPropagation()}
            />
            {/* Gold frame accent */}
            <div className="absolute inset-4 md:inset-12 border border-gold/10 rounded-3xl pointer-events-none" />
          </div>
        )}
      </div>
    </section>
  );
}

/* ───────────────────────── REVIEWS ───────────────────────── */
function Reviews({ dark }: { dark: boolean }) {
  const rev = useScrollReveal();

  return (
    <section id="reviews" className={`py-20 md:py-32 relative overflow-hidden ${dark ? "dark-gradient" : "light-gradient"}`}>
      <div className="absolute top-20 left-10 w-64 h-64 bg-gold/[0.03] rounded-full blur-[100px]" />
      <div className="absolute bottom-20 right-10 w-80 h-80 bg-gold/[0.02] rounded-full blur-[120px]" />
      <div className="max-w-7xl mx-auto px-5 md:px-8">
        <div ref={rev.ref} className={`reveal ${rev.visible ? "visible" : ""}`}>
          <SectionHeader dark={dark} subtitle="Testimonials" title="What Our Clients Say" light="Don't just take our word for it — hear from our happy clients who love the Neo Star experience." />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-5">
          {REVIEWS.map((r, i) => {
            const sr = useScrollReveal();
            return (
              <div
                key={i}
                ref={sr.ref}
                className={`reveal card-premium rounded-2xl p-6 md:p-7 border transition-all duration-500 hover:shadow-2xl group ${dark
                  ? "bg-dark-card/40 border-white/[0.06] hover:border-gold/20 hover:shadow-black/30"
                  : "bg-white border-gold/[0.08] hover:border-gold/25 hover:shadow-gold/[0.08]"
                } ${sr.visible ? "visible" : ""}`}
                style={{ transitionDelay: `${i * 80}ms` }}
              >
                {/* Google icon area */}
                <div className="flex items-center justify-between mb-4">
                  <Quote className={`w-8 h-8 ${dark ? "text-gold/15" : "text-gold/20"}`} />
                  <div className="flex items-center gap-1.5">
                    <div className="w-4 h-4 rounded-sm bg-blue-500/20 flex items-center justify-center">
                      <span className="text-blue-400 text-[8px] font-bold">G</span>
                    </div>
                    <span className={`text-[10px] font-medium ${dark ? "text-gray-600" : "text-gray-400"}`}>Google</span>
                  </div>
                </div>

                {/* Stars */}
                <div className="flex gap-0.5 mb-4">
                  {Array.from({ length: r.rating }).map((_, j) => (
                    <Star key={j} className="w-4 h-4 text-gold fill-gold" />
                  ))}
                </div>

                <p className={`text-sm md:text-[15px] leading-relaxed mb-6 ${dark ? "text-gray-300" : "text-gray-600"}`}>
                  &ldquo;{r.text}&rdquo;
                </p>

                <div className="flex items-center gap-3 pt-4 border-t border-white/5">
                  <div className="w-10 h-10 rounded-full bg-gradient-to-br from-gold/20 to-gold/5 flex items-center justify-center">
                    <span className="text-gold font-bold text-xs">{r.avatar}</span>
                  </div>
                  <div>
                    <p className={`font-semibold text-sm ${dark ? "text-white" : "text-charcoal"}`}>{r.name}</p>
                    <p className={`text-[11px] ${dark ? "text-gray-600" : "text-gray-400"}`}>{r.time}</p>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}

/* ───────────────────────── LOCATION ───────────────────────── */
function Location({ dark }: { dark: boolean }) {
  const rev = useScrollReveal();

  return (
    <section id="location" className={`py-20 md:py-32 relative ${dark ? "dark-luxury" : "bg-light-bg"}`}>
      <div className="max-w-7xl mx-auto px-5 md:px-8">
        <div ref={rev.ref} className={`reveal ${rev.visible ? "visible" : ""}`}>
          <SectionHeader dark={dark} subtitle="Find Us" title="Visit Our Salon" light="Located in the heart of Muzaffarnagar — we're easy to find and always ready to welcome you." />
        </div>

        <div className="grid lg:grid-cols-2 gap-5 md:gap-8 items-stretch">
          {/* Map placeholder */}
          <div className={`rounded-3xl overflow-hidden border ${dark ? "border-white/5" : "border-gold/10"}`}>
            <div className={`relative w-full h-full min-h-[350px] md:min-h-[440px] flex items-center justify-center ${dark
              ? "bg-gradient-to-br from-dark-card to-dark-bg"
              : "bg-gradient-to-br from-gold/[0.03] to-gold/[0.06]"
            }`}>
              {/* Decorative map rings */}
              <div className="absolute inset-0 flex items-center justify-center">
                <div className={`w-64 h-64 rounded-full border ${dark ? "border-gold/[0.04]" : "border-gold/[0.08]"}`} />
                <div className={`absolute w-44 h-44 rounded-full border ${dark ? "border-gold/[0.06]" : "border-gold/[0.1]"}`} />
                <div className={`absolute w-24 h-24 rounded-full border ${dark ? "border-gold/[0.08]" : "border-gold/[0.12]"}`} />
                {/* Center pin */}
                <div className="absolute w-16 h-16 bg-gold/10 rounded-full flex items-center justify-center animate-pulse-gold">
                  <MapPin className="w-7 h-7 text-gold" />
                </div>
              </div>

              {/* Corner accents */}
              <div className="absolute top-6 left-6 text-left">
                <h3 className={`font-display text-lg font-bold ${dark ? "text-white" : "text-charcoal"}`}>Neo Star Salon</h3>
                <p className={`text-xs mt-1 ${dark ? "text-gray-500" : "text-gray-500"}`}>Shri Ramplaza, New Mandi</p>
              </div>

              {/* Get Directions overlay button */}
              <a href={DIRECTIONS_LINK} target="_blank" rel="noopener noreferrer" className="absolute bottom-6 left-6 right-6 flex items-center justify-center gap-2 bg-gold/10 hover:bg-gold/20 border border-gold/20 text-gold font-semibold text-sm py-3 rounded-xl transition-all">
                <Navigation className="w-4 h-4" /> Open in Maps
              </a>
            </div>
          </div>

          {/* Info */}
          <div className={`rounded-3xl p-8 md:p-10 border flex flex-col justify-between ${dark
            ? "bg-dark-card/30 border-white/[0.06]"
            : "bg-white border-gold/[0.08]"
          }`}>
            <div>
              <div className="flex items-center gap-4 mb-8">
                <div className="w-14 h-14 bg-gradient-to-br from-gold/15 to-gold/5 rounded-2xl flex items-center justify-center">
                  <MapPin className="w-6 h-6 text-gold" />
                </div>
                <div className="flex items-center gap-3">
                  <div>
                    <h3 className={`font-display text-xl font-bold ${dark ? "text-white" : "text-charcoal"}`}>Our Address</h3>
                  </div>
                  <OpenBadge dark={dark} />
                </div>
              </div>
              <p className={`text-base leading-relaxed mb-8 ${dark ? "text-gray-300" : "text-gray-600"}`}>
                Shri Ramplaza, Gher Khatti,<br />
                New Mandi, Muzaffarnagar,<br />
                Uttar Pradesh 251001
              </p>

              <div className="space-y-4 mb-10">
                {[
                  { icon: <Phone className="w-4 h-4" />, text: "+91 99999 99999" },
                  { icon: <Clock className="w-4 h-4" />, text: "Mon - Sun: 9:00 AM - 9:00 PM" },
                  { icon: <MessageCircle className="w-4 h-4" />, text: "WhatsApp available for bookings" },
                ].map((item, i) => (
                  <div key={i} className="flex items-center gap-3">
                    <div className="text-gold">{item.icon}</div>
                    <span className={`text-sm ${dark ? "text-gray-400" : "text-gray-600"}`}>{item.text}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Action buttons */}
            <div className="grid grid-cols-2 gap-3">
              <a href={DIRECTIONS_LINK} target="_blank" rel="noopener noreferrer" className={`flex items-center justify-center gap-2 py-4 rounded-xl font-semibold text-sm transition-all border ${dark
                ? "bg-gold/[0.06] text-gold hover:bg-gold/[0.12] border-gold/15"
                : "bg-gold/[0.06] text-gold hover:bg-gold/[0.12] border-gold/20"
              }`}>
                <Navigation className="w-4 h-4" /> Directions
              </a>
              <a href={CALL_LINK} className="flex items-center justify-center gap-2 bg-gradient-to-r from-gold to-gold-light text-dark-bg py-4 rounded-xl font-semibold text-sm transition-all hover:shadow-lg hover:shadow-gold/20">
                <Phone className="w-4 h-4" /> Call Now
              </a>
              <a href={WHATSAPP_LINK} target="_blank" rel="noopener noreferrer" className="col-span-2 flex items-center justify-center gap-2 bg-emerald-600 hover:bg-emerald-500 text-white py-4 rounded-xl font-semibold text-sm transition-all hover:shadow-lg hover:shadow-emerald-500/20">
                <MessageCircle className="w-4 h-4" /> WhatsApp Us
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

/* ───────────────────────── CONTACT ───────────────────────── */
function Contact({ dark }: { dark: boolean }) {
  const rev = useScrollReveal();

  const contactItems = [
    { icon: <Phone className="w-6 h-6" />, label: "Phone", value: "+91 99999 99999", link: CALL_LINK },
    { icon: <MessageCircle className="w-6 h-6" />, label: "WhatsApp", value: "Chat with us", link: WHATSAPP_LINK },
    { icon: <Clock className="w-6 h-6" />, label: "Hours", value: "Mon-Sun: 9AM - 9PM", link: null },
    { icon: <Mail className="w-6 h-6" />, label: "Email", value: "hello@neostarsalon.com", link: "mailto:hello@neostarsalon.com" },
  ];

  return (
    <section id="contact" className={`py-20 md:py-32 relative overflow-hidden ${dark ? "dark-gradient" : "light-gradient"}`}>
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[600px] h-[600px] bg-gold/[0.03] rounded-full blur-[150px]" />
      <div className="max-w-7xl mx-auto px-5 md:px-8 relative">
        <div ref={rev.ref} className={`reveal ${rev.visible ? "visible" : ""}`}>
          <SectionHeader dark={dark} subtitle="Get In Touch" title="Contact Us" light="Have a question or want to book an appointment? Reach out through any of these channels." />
        </div>

        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-5">
          {contactItems.map((c, i) => {
            const sr = useScrollReveal();
            const Wrapper = c.link ? "a" : "div";
            const linkProps = c.link ? { href: c.link, target: c.link.startsWith("http") ? "_blank" : undefined, rel: c.link.startsWith("http") ? "noopener noreferrer" : undefined } : {};
            return (
              <Wrapper
                key={i}
                ref={sr.ref}
                className={`reveal card-premium rounded-2xl p-5 md:p-7 text-center border transition-all duration-500 group ${dark
                  ? "bg-dark-card/30 border-white/[0.06] hover:border-gold/20"
                  : "bg-white border-gold/[0.08] hover:border-gold/25 hover:shadow-xl hover:shadow-gold/[0.06]"
                } ${sr.visible ? "visible" : ""} ${c.link ? "cursor-pointer hover:scale-[1.03]" : ""}`}
                style={{ transitionDelay: `${i * 80}ms` }}
                {...(linkProps as any)}
              >
                <div className={`w-14 h-14 rounded-2xl flex items-center justify-center mx-auto mb-4 transition-all duration-300 ${dark
                  ? "bg-gold/[0.08] text-gold group-hover:bg-gold/[0.15]"
                  : "bg-gold/[0.08] text-gold group-hover:bg-gold/[0.15]"
                }`}>
                  {c.icon}
                </div>
                <h3 className={`font-display text-base md:text-lg font-bold mb-1 ${dark ? "text-white" : "text-charcoal"}`}>{c.label}</h3>
                <p className={`text-xs md:text-sm ${dark ? "text-gray-500" : "text-gray-500"}`}>{c.value}</p>
              </Wrapper>
            );
          })}
        </div>

        {/* Premium CTA Banner */}
        <div className={`mt-16 rounded-3xl p-8 md:p-14 text-center relative overflow-hidden ${dark
          ? "bg-gradient-to-r from-gold/[0.06] via-gold/[0.02] to-gold/[0.06] border border-gold/10"
          : "bg-gradient-to-r from-gold/[0.1] via-gold/[0.03] to-gold/[0.1] border border-gold/15"
        }`}>
          {/* Shimmer overlay */}
          <div className="absolute inset-0 animate-shimmer" />
          {/* Decorative corner elements */}
          <div className="absolute top-0 left-0 w-20 h-20 border-t border-l border-gold/10 rounded-tl-3xl" />
          <div className="absolute bottom-0 right-0 w-20 h-20 border-b border-r border-gold/10 rounded-br-3xl" />

          <div className="relative">
            <div className="flex items-center justify-center gap-2 mb-4">
              <Sparkles className="w-5 h-5 text-gold" />
            </div>
            <h3 className={`font-display text-2xl md:text-4xl font-bold mb-4 ${dark ? "gradient-text-dark" : "text-charcoal"}`}>
              Ready for a <span className="gold-text">Transformation?</span>
            </h3>
            <p className={`mb-10 max-w-lg mx-auto text-sm md:text-base ${dark ? "text-gray-500" : "text-gray-500"}`}>
              Book your appointment today and experience the luxury grooming you deserve.
            </p>
            <a href={WHATSAPP_LINK} target="_blank" rel="noopener noreferrer" className="group inline-flex items-center gap-3 btn-gold text-dark-bg font-bold px-10 py-4 rounded-2xl text-sm">
              <MessageCircle className="w-5 h-5 relative z-10" />
              <span className="relative z-10">Book on WhatsApp Now</span>
              <ArrowRight className="w-4 h-4 relative z-10 group-hover:translate-x-1 transition-transform" />
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}

/* ───────────────────────── FOOTER ───────────────────────── */
function Footer({ dark }: { dark: boolean }) {
  return (
    <footer className={`pt-16 pb-28 md:pb-14 relative ${dark ? "bg-[#080808] border-t border-white/5" : "bg-white border-t border-gold/10"}`}>
      {/* Top gold line */}
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-gold/20 to-transparent" />

      <div className="max-w-7xl mx-auto px-5 md:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10 mb-14">
          {/* Brand */}
          <div className="lg:col-span-2">
            <div className="flex items-center gap-2.5 mb-5">
              <Diamond className="w-5 h-5 text-gold" />
              <span className="font-display text-xl font-bold tracking-tight">
                <span className="text-gold">Neo</span>
                <span className={dark ? "text-white" : "text-charcoal"}> Star</span>
                <span className="text-gold"> Salon</span>
              </span>
            </div>
            <p className={`text-sm leading-relaxed max-w-md mb-6 ${dark ? "text-gray-500" : "text-gray-500"}`}>
              Muzaffarnagar&apos;s premier luxury grooming and beauty destination. Experience the perfect blend of artistry and elegance at Neo Star Salon.
            </p>
            <div className="flex gap-2">
              {[
                { label: "Instagram", color: "hover:bg-pink-500/10 hover:text-pink-400", path: "M7.8 2h8.4C19.4 2 22 4.6 22 7.8v8.4a5.8 5.8 0 0 1-5.8 5.8H7.8C4.6 22 2 19.4 2 16.2V7.8A5.8 5.8 0 0 1 7.8 2m-.2 2A3.6 3.6 0 0 0 4 7.6v8.8C4 18.39 5.61 20 7.6 20h8.8a3.6 3.6 0 0 0 3.6-3.6V7.6C20 5.61 18.39 4 16.4 4H7.6m9.65 1.5a1.25 1.25 0 1 1 0 2.5 1.25 1.25 0 0 1 0-2.5M12 7a5 5 0 1 1 0 10 5 5 0 0 1 0-10m0 2a3 3 0 1 0 0 6 3 3 0 0 0 0-6z" },
                { label: "Facebook", color: "hover:bg-blue-500/10 hover:text-blue-400", path: "M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z" },
                { label: "Twitter", color: "hover:bg-sky-500/10 hover:text-sky-400", path: "M22 4s-.7 2.1-2 3.4c1.6 10-9.4 17.3-18 11.6 2.2.1 4.4-.6 6-2C3 15.5.5 9.6 3 5c2.2 2.6 5.6 4.1 9 4-.9-4.2 4-6.6 7-3.8 1.1 0 3-1.2 3-1.2z" },
              ].map(({ label, color, path }, i) => (
                <a key={i} href="#" aria-label={label} className={`w-10 h-10 rounded-xl flex items-center justify-center transition-all duration-300 ${dark
                  ? `bg-white/5 text-gray-500 hover:text-gold hover:bg-gold/10`
                  : `bg-gold/5 text-gray-400 hover:text-gold hover:bg-gold/10`
                } ${color}`}>
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d={path} /></svg>
                </a>
              ))}
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className={`font-display font-bold text-sm mb-5 flex items-center gap-2 ${dark ? "text-white" : "text-charcoal"}`}>
              <div className="w-4 h-px bg-gold" />
              Quick Links
            </h4>
            <div className="space-y-3">
              {["About", "Services", "Gallery", "Reviews", "Contact"].map((l) => (
                <a key={l} href={`#${l.toLowerCase()}`} className={`block text-sm transition-colors duration-300 ${dark ? "text-gray-500 hover:text-gold" : "text-gray-500 hover:text-gold"}`}>
                  {l}
                </a>
              ))}
            </div>
          </div>

          {/* Contact */}
          <div>
            <h4 className={`font-display font-bold text-sm mb-5 flex items-center gap-2 ${dark ? "text-white" : "text-charcoal"}`}>
              <div className="w-4 h-px bg-gold" />
              Contact
            </h4>
            <div className="space-y-3">
              <p className={`text-sm ${dark ? "text-gray-500" : "text-gray-500"}`}>Shri Ramplaza, New Mandi, Muzaffarnagar, UP 251001</p>
              <a href={CALL_LINK} className={`block text-sm transition-colors ${dark ? "text-gray-500 hover:text-gold" : "text-gray-500 hover:text-gold"}`}>+91 99999 99999</a>
              <a href={WHATSAPP_LINK} target="_blank" rel="noopener noreferrer" className="block text-sm text-emerald-500 hover:text-emerald-400 transition-colors">WhatsApp Us</a>
              <p className={`text-sm ${dark ? "text-gray-500" : "text-gray-500"}`}>Mon-Sun: 9AM - 9PM</p>
            </div>
          </div>
        </div>

        <GoldDivider />

        <div className="flex flex-col md:flex-row items-center justify-between gap-4 mt-8">
          <p className={`text-[11px] ${dark ? "text-gray-600" : "text-gray-400"}`}>
            © {new Date().getFullYear()} Neo Star Salon. All rights reserved.
          </p>
          <p className={`text-[11px] flex items-center gap-1 ${dark ? "text-gray-600" : "text-gray-400"}`}>
            Crafted with <Heart className="w-3 h-3 text-gold fill-gold" /> for excellence
          </p>
        </div>
      </div>
    </footer>
  );
}

/* ───────────────────────── FLOATING WHATSAPP ───────────────────────── */
function FloatingWhatsApp() {
  const [show, setShow] = useState(false);
  useEffect(() => {
    const t = setTimeout(() => setShow(true), 2500);
    return () => clearTimeout(t);
  }, []);

  if (!show) return null;

  return (
    <a
      href={WHATSAPP_LINK}
      target="_blank"
      rel="noopener noreferrer"
      className="fixed bottom-20 md:bottom-8 right-4 md:right-8 z-50 w-14 h-14 bg-emerald-500 hover:bg-emerald-400 text-white rounded-full flex items-center justify-center shadow-xl shadow-emerald-500/30 hover:shadow-2xl hover:shadow-emerald-500/40 transition-all duration-300 hover:scale-110 animate-pulse-gold group"
      aria-label="Chat on WhatsApp"
    >
      <MessageCircle className="w-6 h-6" />
      {/* Tooltip */}
      <span className="absolute right-full mr-3 px-3 py-1.5 bg-dark-bg text-white text-[11px] font-medium rounded-lg whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none shadow-xl hidden md:block">
        Chat with us!
      </span>
    </a>
  );
}

/* ───────────────────────── STICKY MOBILE BAR ───────────────────────── */
function MobileActionBar() {
  const [saved, setSaved] = useState(false);

  return (
    <div className="fixed bottom-0 left-0 right-0 z-50 md:hidden safe-bottom">
      <div className="mobile-action-bar">
        <div className="flex items-center justify-around py-1.5 px-3 max-w-lg mx-auto">
          <a href={CALL_LINK} className="mobile-action-btn text-gold">
            <div className="w-8 h-8 rounded-full bg-gold/10 flex items-center justify-center mb-0.5">
              <Phone className="w-4 h-4" />
            </div>
            <span className="text-[9px] font-bold tracking-wide">Call</span>
          </a>
          <a href={WHATSAPP_LINK} target="_blank" rel="noopener noreferrer" className="mobile-action-btn text-emerald-400">
            <div className="w-8 h-8 rounded-full bg-emerald-500/10 flex items-center justify-center mb-0.5">
              <MessageCircle className="w-4 h-4" />
            </div>
            <span className="text-[9px] font-bold tracking-wide">WhatsApp</span>
          </a>
          <a href={DIRECTIONS_LINK} target="_blank" rel="noopener noreferrer" className="mobile-action-btn text-gold">
            <div className="w-8 h-8 rounded-full bg-gold/10 flex items-center justify-center mb-0.5">
              <Navigation className="w-4 h-4" />
            </div>
            <span className="text-[9px] font-bold tracking-wide">Directions</span>
          </a>
          <button
            onClick={() => setSaved(!saved)}
            className="mobile-action-btn text-gold"
          >
            <div className={`w-8 h-8 rounded-full flex items-center justify-center mb-0.5 transition-all ${saved ? "bg-gold/20" : "bg-gold/10"}`}>
              {saved ? <Bookmark className="w-4 h-4 fill-gold" /> : <Bookmark className="w-4 h-4" />}
            </div>
            <span className="text-[9px] font-bold tracking-wide">{saved ? "Saved" : "Save"}</span>
          </button>
        </div>
      </div>
    </div>
  );
}

/* ───────────────────────── APP ───────────────────────── */
export default function App() {
  const [dark, setDark] = useState(true);

  return (
    <div className={`min-h-screen font-body transition-colors duration-500 ${dark ? "bg-dark-bg text-white" : "bg-light-bg text-charcoal"}`}>
      <Navbar dark={dark} setDark={setDark} />
      <Hero />
      <About dark={dark} />
      <GoldDivider />
      <Services dark={dark} />
      <Gallery dark={dark} />
      <GoldDivider />
      <Reviews dark={dark} />
      <Location dark={dark} />
      <GoldDivider />
      <Contact dark={dark} />
      <Footer dark={dark} />
      <FloatingWhatsApp />
      <MobileActionBar />
    </div>
  );
}
